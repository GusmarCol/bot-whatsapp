# Bot WhatsApp con WWebJS en Replit

Este proyecto configura un bot de WhatsApp que:
- Responde FAQs automáticas.
- Detecta palabras clave de interés de compra y te notifica.
- Permite seguir usando tu número desde Replit.

## Pasos para desplegar en Replit

1. Crea un nuevo Replit y selecciona **Import from ZIP**.
2. Sube este archivo `bot-replit.zip`.
3. En la consola de Replit, espera a que corra `npm install && npm start`.
4. Escanea el QR que aparecerá usando tu WhatsApp Web (tu teléfono).
5. ¡Listo! El bot está en línea 24/7.

## Configuración

- **faq.json**: Modifica directamente en Replit para añadir o cambiar preguntas y respuestas.
- **index.js**: Sustituye `TU_NUMERO@c.us` en la línea de notificaciones por tu número completo de WhatsApp (p.ej. `525512345678@c.us`).
- **Triggers**: Ajusta el array `triggers` con las frases que indicarían intención de compra.

Si tienes dudas, escríbeme y paramos la máquina para actualizar.
