const { Client, LocalAuth } = require('whatsapp-web.js');
const qrcode = require('qrcode-terminal');
const fs = require('fs');

// Carga FAQs
const faqs = JSON.parse(fs.readFileSync('faq.json', 'utf-8'));

// Palabras clave para gatillar notificación
const triggers = ["quiero contratar", "precio final", "cómo contrato"];

const client = new Client({
  authStrategy: new LocalAuth(),
});

client.on('qr', qr => {
  qrcode.generate(qr, { small: true });
});

client.on('ready', () => {
  console.log('✅ Bot listo y conectado');
});

client.on('message', async msg => {
  const texto = msg.body.toLowerCase();
  let responded = false;

  // Responder FAQ
  for (let pregunta in faqs) {
    if (texto.includes(pregunta.toLowerCase())) {
      await msg.reply(faqs[pregunta]);
      responded = true;
      break;
    }
  }

  // Notificación de gatillo
  for (let word of triggers) {
    if (texto.includes(word)) {
      // Reenviar mensaje al propio usuario (cambia '1234567890@c.us' por tu número)
      await client.sendMessage('TU_NUMERO@c.us', `⚡ Prospecto listo: "${msg.body}"`);
      responded = true;
      break;
    }
  }

  // Mensaje de espera
  if (!responded) {
    await msg.reply('Gracias por escribir. Un asesor humano te contactará en breve.');
  }
});

client.initialize();
